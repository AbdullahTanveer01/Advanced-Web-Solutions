
from django.contrib import admin
from django.urls import path

from monitoring.views import comments_view, pressure_trend, heatmap_view, pressure_alert

urlpatterns = [
    path('admin/', admin.site.urls),
    path('comments/', comments_view),
    path('trend/', pressure_trend),
    path('heatmap/', heatmap_view),
    path('alert/', pressure_alert),
]